function InOrOut() 
{

var SayDineIn = document.querySelector("#SayDineIn").value; 


}



function  SayTakeOut()
{


var SayTakeOut = document.querySelector("#SayTakeOut").value;


}


const updateButton = document.getElementById("update-button");
const orderButton = document.getElementById("order-button");
const orderSummary = document.getElementById("order-summary");

updateButton.addEventListener("click", function() {

  const service = document.querySelector('input[name="service"]:checked').value;
  const flavor = document.getElementById("flavors").value;
  const toppings = Array.from(document.querySelectorAll('input[name="toppings"]:checked'))
                        .map(input => input.value);
  const scoops = document.getElementById("scoops").value;

  
  let summary = `You ordered ${scoops} scoop(s) of ${flavor} ice cream with `;
  summary += toppings.length > 0 ? toppings.join(", ") + " toppings. " : "no toppings. ";
  if (service === "dine-in") {
    const tableNumber = Math.floor(Math.random() * 41) + 10; 
    summary += `Your table number is ${tableNumber}.`;
  }
  orderSummary.textContent = summary;
});

orderButton.addEventListener("click", function() {
  
  alert("Order submitted");
});


const orderTypeElement = document.getElementById("order-type");
const iceCreamFlavorElement = document.getElementById("ice-cream-flavor");
const toppingsElement = document.getElementById("toppings");
const scoopsElement = document.getElementById("scoops");


const orderData = JSON.parse(localStorage.getItem("order"));


orderTypeElement.innerHTML = orderData.dineIn ? "Dine In" : "Take Out";
iceCreamFlavorElement.innerHTML = orderData.iceCreamFlavor;
toppingsElement.innerHTML = orderData.toppings.join(", ");
scoopsElement.innerHTML = orderData.numberOfScoops;


localStorage.removeItem("order");